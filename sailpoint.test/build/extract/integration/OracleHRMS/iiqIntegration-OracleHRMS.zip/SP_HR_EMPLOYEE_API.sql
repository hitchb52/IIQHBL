create or replace Package SP_HR_EMPLOYEE_API as

procedure create_employee
(  p_hire_date  in     date
  ,p_business_group_id             in     number
  ,p_last_name                     in     varchar2
  ,p_first_name                    in     varchar2
  ,p_middle_names                  in     varchar2 default null
  ,p_sex                           in     varchar2
  ,p_known_as                      in     varchar2 default null
  ,p_employee_number               in out nocopy varchar2
  ,p_person_id                        out nocopy number
  ,p_assignment_id                    out nocopy number
  ,p_per_object_version_number        out nocopy number
  ,p_asg_object_version_number        out nocopy number
  ,p_per_effective_start_date         out nocopy date
  ,p_per_effective_end_date           out nocopy date
  ,p_full_name                        out nocopy varchar2
  ,p_per_comment_id                   out nocopy number
  ,p_assignment_sequence              out nocopy number
  ,p_assignment_number                out nocopy varchar2
  ,p_name_combination_warning         out nocopy boolean
  ,p_assign_payroll_warning           out nocopy boolean
  ,p_orig_hire_warning                out nocopy boolean
);
end SP_HR_EMPLOYEE_API;