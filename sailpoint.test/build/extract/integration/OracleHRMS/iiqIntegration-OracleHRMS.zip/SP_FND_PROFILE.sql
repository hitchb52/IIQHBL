create or replace package SP_FND_PROFILE as

/*
    ** VALUE_SPECIFIC - Get profile value for a specific user/resp/appl combo
    **   Default is user/resp/appl is current login.
    */
    function VALUE_SPECIFIC(NAME              in varchar2,
                            USER_ID           in number default null,
                            RESPONSIBILITY_ID in number default null,
                            APPLICATION_ID    in number default null,
                            ORG_ID            in number default null,
                            SERVER_ID         in number default null)
    return varchar2;

end SP_FND_PROFILE;