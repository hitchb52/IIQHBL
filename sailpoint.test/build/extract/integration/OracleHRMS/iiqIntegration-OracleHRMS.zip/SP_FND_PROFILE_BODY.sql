create or replace package body SP_FND_PROFILE as

    function VALUE_SPECIFIC(NAME              in varchar2,
                            USER_ID           in number default null,
                            RESPONSIBILITY_ID in number default null,
                            APPLICATION_ID    in number default null,
                            ORG_ID            in number default null,
                            SERVER_ID         in number default null) return varchar2 is
    resultVal  varchar2(200);
    begin
 resultVal := FND_PROFILE.VALUE_SPECIFIC(NAME ,USER_ID ,RESPONSIBILITY_ID ,APPLICATION_ID ,ORG_ID ,SERVER_ID );
  return resultVal;       
    end ;

end SP_FND_PROFILE;