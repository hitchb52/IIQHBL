create or replace Package body SP_HR_EMPLOYEE_API as

procedure create_employee
(  p_hire_date  in     date
  ,p_business_group_id             in     number
  ,p_last_name                     in     varchar2
  ,p_first_name                    in     varchar2
  ,p_middle_names                  in     varchar2 default null
  ,p_sex                           in     varchar2
  ,p_known_as                      in     varchar2 default null
  ,p_employee_number               in out nocopy varchar2
  ,p_person_id                        out nocopy number
  ,p_assignment_id                    out nocopy number
  ,p_per_object_version_number        out nocopy number
  ,p_asg_object_version_number        out nocopy number
  ,p_per_effective_start_date         out nocopy date
  ,p_per_effective_end_date           out nocopy date
  ,p_full_name                        out nocopy varchar2
  ,p_per_comment_id                   out nocopy number
  ,p_assignment_sequence              out nocopy number
  ,p_assignment_number                out nocopy varchar2
  ,p_name_combination_warning         out nocopy boolean
  ,p_assign_payroll_warning           out nocopy boolean
  ,p_orig_hire_warning                out nocopy boolean
) is
begin
HR_EMPLOYEE_API.create_employee
(
p_hire_date => p_hire_date
  ,p_business_group_id => p_business_group_id
  ,p_last_name => p_last_name
  ,p_first_name => p_first_name
  ,p_middle_names => p_middle_names
  ,p_sex => p_sex
  ,p_known_as => p_known_as
  ,p_employee_number => p_employee_number
  ,p_person_id => p_person_id
  ,p_assignment_id => p_assignment_id
  ,p_per_object_version_number => p_per_object_version_number
  ,p_asg_object_version_number => p_asg_object_version_number
  ,p_per_effective_start_date => p_per_effective_start_date
  ,p_per_effective_end_date => p_per_effective_end_date
  ,p_full_name => p_full_name
  ,p_per_comment_id => p_per_comment_id
  ,p_assignment_sequence => p_assignment_sequence
  ,p_assignment_number => p_assignment_number
  ,p_name_combination_warning => p_name_combination_warning
  ,p_assign_payroll_warning => p_assign_payroll_warning
  ,p_orig_hire_warning =>p_orig_hire_warning
);
end create_employee;

end SP_HR_EMPLOYEE_API;