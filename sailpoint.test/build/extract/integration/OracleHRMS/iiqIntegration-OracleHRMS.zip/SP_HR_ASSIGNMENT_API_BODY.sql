create or replace Package body sp_hr_assignment_api as

procedure update_emp_asg_criteria
(
   p_effective_date               in     date
  ,p_datetrack_update_mode        in     varchar2
  ,p_assignment_id                in     number
  ,p_job_id                       in     number   default hr_api.g_number
  ,p_people_group_id              in out nocopy number
  ,p_object_version_number        in out nocopy number
  ,p_special_ceiling_step_id      in out nocopy number
  ,p_group_name                      out nocopy varchar2
  ,p_effective_start_date            out nocopy date
  ,p_effective_end_date              out nocopy date
  ,p_org_now_no_manager_warning      out nocopy boolean
  ,p_other_manager_warning           out nocopy boolean
  ,p_spp_delete_warning              out nocopy boolean
  ,p_entries_changed_warning         out nocopy varchar2
  ,p_tax_district_changed_warning    out nocopy boolean
) is
begin
hr_assignment_api.update_emp_asg_criteria
(
p_effective_date => p_effective_date
  ,p_datetrack_update_mode => p_datetrack_update_mode
  ,p_assignment_id => p_assignment_id
  ,p_job_id => p_job_id
  ,p_people_group_id => p_people_group_id
  ,p_object_version_number => p_object_version_number
  ,p_special_ceiling_step_id => p_special_ceiling_step_id
  ,p_group_name => p_group_name
  ,p_effective_start_date => p_effective_start_date
  ,p_effective_end_date => p_effective_end_date
  ,p_org_now_no_manager_warning => p_org_now_no_manager_warning
  ,p_other_manager_warning => p_other_manager_warning
  ,p_spp_delete_warning => p_spp_delete_warning
  ,p_entries_changed_warning => p_entries_changed_warning
  ,p_tax_district_changed_warning => p_tax_district_changed_warning
);
end update_emp_asg_criteria;

end sp_hr_assignment_api;
